﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;


public class PlayerControl : NetworkBehaviour
{

    public float x = .15f;
    //public static bool PausedGame = false;

    public GameObject player;
    public GameObject projectile;
    public Transform gearSpawn;
    public Text txt;

    [SyncVar]
    public float trailTime = 1;

       private void Start()
        {
            txt = gameObject.GetComponent<Text>();
            txt.text = "";
        }

    void Update()
    {

        GetComponent<TrailRenderer>().lifeTime = trailTime;
        Debug.Log(trailTime);

/*        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (PausedGame)
            {
                Resume();
                //if game is already paused, resume
            }
            else
            {
                Pause();
                //else pause
            }
        }*/

        if (!isLocalPlayer)
        {
            return;
        }

        if (Input.GetKeyDown("space"))
        {
            if (trailTime > 0.2f)
            {
                CmdFire();
            }
        }

        //the player movement of cloxic is a bit unique in that the player is always in motion but the player can control the movement
        //the below WASD functions control the turning of the game, the quaternion numbers are rotationals that change the direction the player faces

        if (Input.GetKey("d"))
        {
            transform.Translate(x, 0, 0);

            transform.rotation = Quaternion.Euler(0, 0, 0);            
        }

        else if (Input.GetKey("a"))
        {
            transform.Translate(x, 0, 0);

            transform.rotation = Quaternion.Euler(0, 180, 0);          
        }

        else if (Input.GetKey("w"))
        {
            transform.Translate(x, 0, 0);

            transform.rotation = Quaternion.Euler(0, -90, 0);            
        }

        else if (Input.GetKey("s"))
        {
            transform.Translate(x, 0, 0);

            transform.rotation = Quaternion.Euler(0, 90, 0);            
        }

        if (Input.GetKey("r"))
        {
            Respawn();
        }

        if (trailTime  < 0.2f)
        {
            CmdKill();
        }

    }

   /* void Resume()
    {
        deathUI.SetActive(false);
        Time.timeScale = 1f;
        PausedGame = false;
    }
    void Pause()
    {
        deathUI.SetActive(true);
        Time.timeScale = 0f;
        //we might want to turn this off for multiplayer entirely instead of trying to get everyone's game to pause.
        PausedGame = true;
    }*/

    void OnTriggerEnter(Collider collider)
    {
        if (!isLocalPlayer)
        {
            return;
        }

        else if (collider.gameObject.GetComponent<PlayerControl>() == null && collider.gameObject.layer == 11)
        {
            Destroy(collider.gameObject);

            CmdPower();
        }

        else if (collider.gameObject.GetComponent<PlayerControl>() == null && collider.gameObject.layer == 10)
        {
            trailTime = trailTime - 0.2f;
            Debug.Log("Hit Trial");            
        }

        else if (collider.gameObject.GetComponent<PlayerControl>() == null && collider.gameObject.layer == 12)
        {
            Destroy(collider.gameObject);

            CmdHurt();
        }
    }

    [Command]
    void CmdFire()
    {
        // Create the Bullet from the Bullet Prefab
        var gear = (GameObject)Instantiate(projectile, gearSpawn.position,
            gearSpawn.rotation);

        // Add velocity to the bullet
        gear.GetComponent<Rigidbody>().velocity = gear.transform.forward * 16;

        // Spawn the bullet on the Clients
        NetworkServer.Spawn(gear);

        // Destroy the bullet after 2 seconds
        Destroy(gear, 2.0f);

        // Shorten trail renderer
        trailTime = trailTime - 0.2f;
    }

    [Command]
    void CmdPower()
    {
        trailTime = trailTime + 0.2f;        
        Debug.Log("Power");
    }

    [Command]
    void CmdKill()
    {
       // txt = gameObject.GetComponent<Text>();
        player.transform.position = new Vector3(0.0f, -12.0f, 0.0f);
       // txt.text = "Press R to Respawn";
    }

    [Command]
    void CmdHurt()
    {
        trailTime = trailTime - 0.4f;
    }

    void Respawn()
    {
        if (trailTime != 1f)
        {
           // txt = gameObject.GetComponent<Text>();
            player.transform.position = new Vector3(0.0f, 2.0f, 0.0f);
            //the transfrom is a constant, the player always has forward motion
            trailTime = 1f;
           // txt.text = "";
        }
            
    }
}