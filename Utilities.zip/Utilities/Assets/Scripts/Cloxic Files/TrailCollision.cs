﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrailCollision : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnCollision2DEnter(PolygonCollider2D collider)
    {
        Debug.Log("collided");

        if(collider.gameObject.layer == 10)
        {
            transform.parent.GetComponent<TrailRenderer>().lifeTime -= 0.2f;
        }
    }
}
