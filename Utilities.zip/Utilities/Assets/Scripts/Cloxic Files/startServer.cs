﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class startServer : MonoBehaviour {

    public Text IP;
    public Text Port;
    public GameObject Canvas;
    

    public void StartServer()
    {/*
        if (IP.text == null)
        {
            IP.text = "localhost";
        }
        else
        {*/
            NetworkManager.singleton.StartServer();
           // Canvas.SetActive(false);
       // }
    }

    public void JoinAsClient()
    {
        if (IP.text == null)
        {
            IP.text = "localhost";
        }

        NetworkManager.singleton.networkAddress = IP.text;
        int x;
        int.TryParse(Port.text, out x);
        NetworkManager.singleton.networkPort = x;
        NetworkManager.singleton.StartHost();
        //this code allows you to join a host for the game via IP
    }

}
