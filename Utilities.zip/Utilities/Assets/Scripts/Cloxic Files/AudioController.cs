﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class AudioController : MonoBehaviour {

    AudioSource gameAudio;

    public AudioClip intro;
    public AudioClip loop;
    public AudioClip outro;

    void Start()
    {
        //Fetch the AudioSource from the GameObject
        gameAudio = GetComponent<AudioSource>();

        //Set the original AudioClip as this clip
        gameAudio.clip = intro;

        gameAudio.Play();

        //Output the current clip's length
        Debug.Log("Audio clip length : " + gameAudio.clip.length);
    }

    void Update()
    {
        //Press this key to switch Audio Clips
        if (!gameAudio.isPlaying && gameAudio.clip == intro)
        {
            SwitchAudio();
        }
    }

    void SwitchAudio()
    {
        //If the current Audio clip is the original Audio clip, switch to the second clip
        if (gameAudio.clip == intro)
        {
            //Switch to the second clip
            gameAudio.clip = loop;

            //Play the second clip
            gameAudio.Play();

            //Make audio loop
            gameAudio.loop = true;

            Debug.Log("Switched");
        }
        //Otherwise, if the current Audio clip is the second clip, switch back
        else if (gameAudio.clip == loop)
        {
            //Switch back to the original Audio clip
            gameAudio.clip = outro;

            //Play the original clip
            gameAudio.Play();

            Debug.Log("Switched again");
        }

        //Ouput the length of the current Audio clip
        Debug.Log("Audio clip length : " + gameAudio.clip.length);
    }
}
