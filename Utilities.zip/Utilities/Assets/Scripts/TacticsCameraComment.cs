﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TacticsCamera : MonoBehaviour 
{
    public void RotateLeft()
    {
        transform.Rotate(Vector3.up, 90, Space.Self);
    }
    //this camera rotation code is made for a specific type of game; an isometric tactical rpg
    //in this type of game rotation by fixed degrees is more useful than a free camera
    //essentially what this does is rotate the camera 90 degrees from its current position
    //the code below code does the opposite, moving it the other direction

    public void RotateRight()
    {
        transform.Rotate(Vector3.up, -90, Space.Self);
    }
}
