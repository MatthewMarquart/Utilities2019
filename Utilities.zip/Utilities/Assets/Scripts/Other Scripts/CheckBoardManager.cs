﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class CheckBoardManager : MonoBehaviour
{
    public GameObject m_Terrain;
    public GameObject m_Plane;
    public GameObject m_Tower;
    public GameObject m_Debris;
    public GameObject m_HostilePref;

    private int m_WidthBoard = 15;
    private int m_DepthBoard = 20;
    private float m_CheckerDistance = 13;
    private bool m_LevelIsViable;
    private GameObject m_CurrentCheck;
    private List<GameObject> m_AllTowers;
    private List<GameObject> m_AllDebris;
    private List<GameObject> m_AllChecks;
    private enum m_DirectionToMove { Up, Down, Left, Right, Null };




    /*
        Pick a starting point, move in a random direction. Have a random probability of picking a new direction.         Never move into an occupied square, if you bump into one the current trail ends.         If the current trail ends pick a square you have already visited and pick a new direction and do a random walk like you did for the first one.         Repeat until the maze is as full as you want it to be.
    */

    void Start () {

    m_AllDebris = new List<GameObject>();     
    m_AllTowers = new List<GameObject>();   
    m_AllChecks = new List<GameObject>();

    SpawnLevelDesign();
    CreatePaths();

    }


private void SpawnLevelDesign()
{

    for (var i = 0; i < m_WidthBoard; i++)
    {

        for (var j = 0; j < m_DepthBoard; j++)
        {
            GameObject check = Instantiate(m_Plane, this.gameObject.transform);
                check.transform.position += new Vector3(-m_CheckerDistance * i, 0, m_CheckerDistance * j);
                check.gameObject.name = "Check-   Width: " + i + " Depth: " + j;
                check.GetComponent<CheckObj>().HorizontalCoordinate = i;
                check.GetComponent<CheckObj>().VerticleCoordinate = j;
                m_AllChecks.Add(check);
            if (i == 7 && j == 0) //Get Starting Check for CreatePaths();                
                {
                    check.GetComponent<CheckObj>().hasBeenPathed = true;
                    m_CurrentCheck = check;
                }

            float decider = Random.Range(0.001f, 1);
            if (decider <= 0.2f) //This is a tower                
                {
                    GameObject tower = Instantiate(m_Tower, check.transform);
                    tower.transform.localPosition = new Vector3(0, 0, 0);
                    m_AllTowers.Add(tower);
                }
                else if (decider > 0.2f && decider <= 0.99f) //This is a debris                
                {
                    GameObject debris = Instantiate(m_Debris, check.transform);
                    debris.transform.localPosition = new Vector3(0, 0, 0);
                    Vector3 randRot = new Vector3(                        
                        debris.transform.localRotation.x,                        
                        debris.transform.localRotation.y * decider,                        
                        debris.transform.localRotation.z);
                    debris.transform.Rotate(randRot);
                    m_AllDebris.Add(debris);
                }
                else
                {                    //this is a blank                
                }
            }
        }
    }

    private void CreatePaths()
    {
        bool cantMoveRight = false;
        bool cantMoveLeft = false;
        bool cantMoveUp = false;
        bool cantMoveDown = false;
        int startingHorPoint = 7; //7 Width        
        int startingVertPoint = 0; //0 Depth        
        Vector2 startingPoint = new Vector2(startingHorPoint, startingVertPoint); 
        int currentHorizontalPos = startingHorPoint; int currentVerticlePos = startingVertPoint;
        int amountOfMoves = 50; //Arbitrary 
                    m_DirectionToMove direction = new m_DirectionToMove();
        for (var i = 0; i < amountOfMoves; i++)
                    {
            //Stuck Check             
            if (cantMoveUp && cantMoveDown && cantMoveLeft && cantMoveRight)
            {
                print("IM STUCK!!!");
                        foreach (GameObject ck in m_AllChecks)
                        {
                            if (ck.GetComponent<CheckObj>().VerticleCoordinate == m_CurrentCheck.GetComponent<CheckObj>().VerticleCoordinate + 2 
                        && ck.GetComponent<CheckObj>().HorizontalCoordinate == m_CurrentCheck.GetComponent<CheckObj>().HorizontalCoordinate)
                            {
                                GameObject curCK = ck;
                                print("Finding Viable Candidate: " + curCK.name);
                                var k = 2;
                                while (curCK.GetComponent<CheckObj>().hasBeenPathed)
                                {
                                    print("Candidate has already been pathed, grabbing next...");
                                    foreach (GameObject ck_2 in m_AllChecks)
                                    {
                                        if (ck_2.GetComponent<CheckObj>().VerticleCoordinate == m_CurrentCheck.GetComponent<CheckObj>().VerticleCoordinate + k && ck_2.GetComponent<CheckObj>().HorizontalCoordinate == m_CurrentCheck.GetComponent<CheckObj>().HorizontalCoordinate)
                                        {
                                            curCK = ck_2;
                                            print("I think I found a good one? - Viable Candidate: " + curCK.name);
                                        }
                                    }
                                    k++;
                                }
                                print("While is done??");

                                m_CurrentCheck = curCK; cantMoveDown = false;
                            }
                        }
                        return;
                    }


            //For Starting Check -->            
            foreach (Transform child in m_CurrentCheck.transform)            {                GameObject.Destroy(child.gameObject);            }//<--
                    int directionNum = Random.Range(0, 5);
                    switch (directionNum)
                    {
                        case 0:
                            direction = m_DirectionToMove.Up; print("Direction #" + i + " is: " + direction);
                            bool redo = SetCurrentCheck(direction); print("REDO: " + redo);
                            if (redo) { cantMoveUp = true; i--; } else { cantMoveUp = false; }
                            break;
                        case 1:
                            direction = m_DirectionToMove.Down; print("Direction #" + i + " is: " + direction);
                            bool redo2 = SetCurrentCheck(direction); print("REDO: " + redo2);
                            if (redo2) { cantMoveDown = true; i--; } else { cantMoveDown = false; }
                            break;
                        case 2:
                            direction = m_DirectionToMove.Left; print("Direction #" + i + " is: " + direction);
                            bool redo3 = SetCurrentCheck(direction); print("REDO: " + redo3);
                            if (redo3) { cantMoveLeft = true; i--; } else { cantMoveLeft = false; }
                            break;
                        case 3:
                            direction = m_DirectionToMove.Right; print("Direction #" + i + " is: " + direction);
                            bool redo4 = SetCurrentCheck(direction); print("REDO: " + redo4);
                            if (redo4) { cantMoveRight = true; i--; } else { cantMoveRight = false; }
                            break;
                        case 5:
                            direction = m_DirectionToMove.Down; print("Direction #" + i + " is: " + direction);
                            bool redo5 = SetCurrentCheck(direction); print("REDO: " + redo5);
                            if (redo5) { cantMoveDown = true; i--; } else { cantMoveDown = false; }
                            break;
                        default:
                            direction = m_DirectionToMove.Null;
                            print("Direction was Null in CreatePaths()");
                            break;
                    }
                }
        }

        private bool SetCurrentCheck(m_DirectionToMove dir)
        {
            int hor = m_CurrentCheck.GetComponent<CheckObj>().HorizontalCoordinate; int vert = m_CurrentCheck.GetComponent<CheckObj>().VerticleCoordinate;
            print("CURRENT HOR: " + hor + "  CURRENT VERT: " + vert);
            int vertOffset = 0; int horOffset = 0;
            switch (dir) { case m_DirectionToMove.Up: vertOffset = 1; break; case m_DirectionToMove.Down: vertOffset = -1; break; case m_DirectionToMove.Left: horOffset = 1; break; case m_DirectionToMove.Right: horOffset = -1; break; }

            foreach (GameObject ck in m_AllChecks)
            {
                if (ck.GetComponent<CheckObj>().HorizontalCoordinate + horOffset == hor && ck.GetComponent<CheckObj>().VerticleCoordinate + vertOffset == vert)
                {
                    print("I found the check for " + dir + ": " + ck.gameObject.name); if (!ck.GetComponent<CheckObj>().hasBeenPathed)
                    {
                        ck.GetComponent<CheckObj>().hasBeenPathed = true; foreach (Transform child in ck.transform)
                        {
                            GameObject.Destroy(child.gameObject);//Destory the visible gameobjects
                            m_CurrentCheck = ck; print("I made " + ck.gameObject.name + " the new current Check and I'm murding all it's children.");
                        }
                    }
                    else
                    {
                        print("This Check has already been pathed");
                        return true;
                    }
                }
            }
            return false;
        }
}

