﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Incomplete_Utilitities : MonoBehaviour
{

    public GameObject prefabSphere;
    public Incomplete_Instantiate instantiate;
    public float spacing = 2f;
    public InputField input;
    public Button maze;

    private int r = 0;

    GameObject newObject;

    //check if button pressed, add listener to instantiatePrefabsEqualSpacing function
    public void Start()
    {
        maze.onClick.AddListener(delegate { instantiatePrefabsEqualSpacing(); });
        //upon clicking the button, add listener for function
    }

    /*public void instantiatePrefab()
    {
        //TODO: Instantiate the linked prefab at the origin (0,0,0)
        newObject = Instantiate(spherePrefab);
    }


    public void instantiatePrefabAtPosition(Vector3 pos)
    {
        instantiatePrefab();
        newObject.transform.position = new;
    }*/


    public void instantiatePrefabsEqualSpacing()
    {

        r = instantiate.r;
        //r is the input field used for the spheres project I believe, and what the user enters

        //TODO: Get the value input by user by accessing a public method of the Instantiate Script
        int cubex = 0;
        int cubey = 0;
        int cubez = 0;

        //wtf is going on here
        Vector3 pos;
        while (cubex < r)
        {
            cubey = 0;
            //GameObject newObject;
            while (cubey < r)
            {
                cubez = 0;
                while (cubez < r)
                {
                    pos = new Vector3(cubex * spacing, cubey * spacing, cubez * spacing);
                    cubez++;
                    //instantiatePrefabAtPosition(pos);
                    newObject = Instantiate(prefabSphere);
                    newObject.transform.position = new Vector3(cubex * spacing, cubey * spacing, cubez * spacing);
                    Debug.Log("cubez");
                }
                Debug.Log("cubey");
                cubey++;
            }
            Debug.Log("cubex");
            cubex++;


            //instantiatePrefabAtPosition(pos);
            //TODO: Write two more loops inside this while loop to make a three dimensional cube with equal spacing between spheres
        }
    }
}
