﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class projectile_shoot : MonoBehaviour {

    GameObject prefab;
	// Use this for initialization
	void Start () {
        prefab = Resources.Load("projectile") as GameObject;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown(0))
        {
            GameObject projectile = Instantiate(prefab) as GameObject;
            //instantiate prefab
            projectile.transform.position = transform.position + Camera.main.transform.forward * 2;
            //using the main camera as a point of reference set the transform of the projectile 
            Rigidbody rb = projectile.GetComponent<Rigidbody>();
            //
            rb.velocity = Camera.main.transform.forward * 20;
            //give object velocity moving away from the main camera, or rather "to the forward of the main camera"

        }
	}
}
