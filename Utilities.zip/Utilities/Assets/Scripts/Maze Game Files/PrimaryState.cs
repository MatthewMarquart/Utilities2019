﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrimaryState : State
{
    public PrimaryState(StateController bigStateController) : base(bigStateController)
    {
    }

    public override void OnStateEnter() 
    {
        bigStateController.agent.destination = bigStateController.goal.gameObject.transform.position;
        //this is the same as the other state, but the target object is different
    }

    public override void Act()
    {
        throw new System.NotImplementedException();

    }

    public override void CheckTransitions()
    {
        throw new System.NotImplementedException();
        //conditions for changing states
    }

    // Start is called before the first frame update
   
}
