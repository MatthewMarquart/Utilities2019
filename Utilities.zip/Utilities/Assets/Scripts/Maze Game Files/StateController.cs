﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class StateController : MonoBehaviour
{
    public NavMeshAgent agent;
    public GameObject goal;
    public GameObject goal2;

    public State currentState;
    // Start is called before the first frame update
    void Start()
    {
        SetState(new PrimaryState(this));   
    }

    // Update is called once per frame
    void Update()
    {
        currentState.CheckTransitions();
        currentState.Act();

    }
    public void SetState(State state)
    {
        if (currentState != null)
        {
            currentState.OnStateExit();
        }

        currentState = state;
        gameObject.name = "AI agent in state " + state.GetType().Name;

        if (currentState != null)
        {
            currentState.OnStateEnter();
        }
        //this statecontroller file is for switching between the states, but it is not currently set up
    }
}
