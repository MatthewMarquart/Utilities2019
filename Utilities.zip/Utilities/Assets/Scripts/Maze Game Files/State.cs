﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class State
{
    protected StateController bigStateController;

    public State(StateController bigStateController)
    {
        this.bigStateController = bigStateController;
    }
    public abstract void CheckTransitions();
    public abstract void Act();
    public virtual void OnStateEnter() { }
    public virtual void OnStateExit() { }

}
//this sets up the state machine for the maze game
//essentially it just has the basics for the states