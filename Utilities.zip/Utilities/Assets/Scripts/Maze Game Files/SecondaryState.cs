﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondaryState : State
{
    public SecondaryState(StateController bigStateController) : base(bigStateController)
    {
    }

    public override void OnStateEnter()
    {
        bigStateController.agent.destination = bigStateController.goal2.gameObject.transform.position;
        //for this particular state, it sets the destination for the AI to the object called goal2
    }

    public override void Act()
    {
        throw new System.NotImplementedException();

    }

    public override void CheckTransitions()
    {
        throw new System.NotImplementedException();
        //conditions for changing states
    }
}
